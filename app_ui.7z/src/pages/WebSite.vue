<template>
  <DevdocSite></DevdocSite>
</template>

<script>
import DevdocSite from "../components/WebSite/DocumentSite";

export default {
  name: "web-side",
  components: { DevdocSite },
  methods: {}
};
</script>

<style></style>

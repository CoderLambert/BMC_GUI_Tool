const state = {
  bmcConfList: null,
  bmcFlashList:null,
  bmcConfFilePath: null,
  bmcImageFile: null,
  bmcImageFilePath: null
};
export default state;

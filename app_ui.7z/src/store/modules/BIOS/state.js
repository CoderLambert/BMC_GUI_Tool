const state = {
  biosConfList: null,
  biosFlashList:null,
  biosConfFilePath: null,
  biosImageFile: null,
  biosImageFilePath: null
};
export default state;
